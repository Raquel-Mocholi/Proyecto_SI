<?php /* Smarty version 3.1.24, created on 2025-03-20 12:17:14
         compiled from "template/admin/common/head.tpl" */ ?>
<?php
/*%%SmartyHeaderCode:25509239667dbf93a43aa80_73079145%%*/
if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4af77cb9575c1535be1406f91060f6e70ec1eb4f' => 
    array (
      0 => 'template/admin/common/head.tpl',
      1 => 1742256099,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '25509239667dbf93a43aa80_73079145',
  'has_nocache_code' => false,
  'version' => '3.1.24',
  'unifunc' => 'content_67dbf93a465121_11700565',
),false);
/*/%%SmartyHeaderCode%%*/
if ($_valid && !is_callable('content_67dbf93a465121_11700565')) {
function content_67dbf93a465121_11700565 ($_smarty_tpl) {

$_smarty_tpl->properties['nocache_hash'] = '25509239667dbf93a43aa80_73079145';
?>
<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Turistic
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <link rel="apple-touch-icon" href="/img/assets/apple-touch-icon.png">
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  
  <?php echo '<script'; ?>
 src="../js/jquery-3.3.1.min.js"><?php echo '</script'; ?>
>
  <?php echo '<script'; ?>
 src="../js/sidebar-accordion.js"><?php echo '</script'; ?>
>
	
  <!-- CSS Files -->
  <link href="../js/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../css/paper-dashboard.min.css?v=2.0.0" rel="stylesheet" media="screen" />
  <link href="../css/jquery-confirm.css" rel="stylesheet"  media="screen"/>
  <link href="../css/stylesheet.css" rel="stylesheet" />
  <link href="../css/print.css" rel="stylesheet" media="print" />
  
  	<!--   Core JS Files   -->
	<?php echo '<script'; ?>
 src="../js/popper.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="../js/bootstrap/js/bootstrap.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="../js/bootstrap-switch.js" ><?php echo '</script'; ?>
>


</head>
<?php }
}
?>